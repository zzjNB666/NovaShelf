export const categories = [
  'Galgame',
  '轻小说',
  '动漫资料',
  '工具资源',
  '音乐资源',
  '其他'
];
