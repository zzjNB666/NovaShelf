# ACGShare 资源分享与评论平台

ACGShare 是一个前后端分离的实训项目，包含资源列表、资源详情、分类搜索、用户注册登录、评论、评分和管理员后台。

## 技术栈

- 前端：Vue 3 + Vite + Vue Router + Axios + lucide-vue-next
- 后端：Node.js + Express + JWT + bcryptjs
- 数据库：MySQL，默认也提供 mock 数据模式，方便先运行演示

## 目录结构

```text
acgshare-frontend/   Vue 前端
acgshare-backend/    Express 后端
```

## 快速运行

后端：

```bash
cd acgshare-backend
copy .env.example .env
npm install
npm run dev
```

前端：

```bash
cd acgshare-frontend
npm install
npm run dev
```

访问：http://localhost:5173

默认 mock 账号：

- 管理员：admin / admin123
- 普通用户：demo / demo123

## 使用 MySQL

1. 在 `acgshare-backend/.env` 中设置：

```env
USE_MOCK_DB=false
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=你的数据库密码
DB_NAME=acgshare
JWT_SECRET=acgshare_secret
PORT=3000
```

2. 初始化数据库：

```bash
cd acgshare-backend
npm run seed
```

也可以在 Navicat 中执行 `acgshare-backend/database/schema.sql`。

## 已实现功能

- 用户注册、登录、获取当前用户信息、退出登录
- 资源列表、详情、分类筛选、关键词搜索、分页、排序
- 管理员新增、编辑、删除资源，支持上传封面图片
- 用户发表评论、查看评论、删除自己的评论
- 管理员删除任意评论、查看用户和统计数据
- 用户评分，后端通过唯一键或 mock 逻辑防止同一用户重复评分
- 后台路由守卫、前后端表单校验、MySQL 常用索引

## 示例资源来源

项目内置的示例资源放在 `acgshare-backend/data/sampleData.js`，下载链接选用公开可访问、授权清晰的页面，包括：

- Ren'Py 官方镜像 SDK
- Project Gutenberg 公版电子书
- OpenGameArt CC0 角色、视觉小说素材和背景音乐
- itch.io 上的 MIT 开源 Ren'Py Rhythm Game 模板
- Project DVN 免费开源视觉小说引擎

## 主要接口

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/profile`
- `GET /api/resources`
- `GET /api/resources/:id`
- `POST /api/resources`
- `PUT /api/resources/:id`
- `DELETE /api/resources/:id`
- `POST /api/uploads/cover`
- `GET /api/resources/:id/comments`
- `POST /api/resources/:id/comments`
- `DELETE /api/comments/:id`
- `POST /api/resources/:id/rating`
- `GET /api/resources/:id/rating`
- `GET /api/admin/stats`

## 生产部署提示

前端生产环境使用 `npm run build` 生成 `dist`，由 Nginx 托管。后端用 PM2 或类似进程管理器运行。

如果启用了封面上传，Nginx 需要同时代理 `/api/` 和 `/uploads/`：

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}

location /uploads/ {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```
