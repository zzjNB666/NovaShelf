const sampleResources = [
  {
    id: 1,
    title: "Ren'Py 官方镜像 SDK",
    cover: '/covers/renpy-sdk.svg',
    category: 'Galgame',
    tags: '视觉小说,引擎,开源',
    description: "Ren'Py 是免费开源的视觉小说引擎，适合制作 Galgame、互动小说和剧情向作品。资源页提供 Windows、macOS、Linux SDK 下载。",
    download_url: 'https://renpytom.itch.io/renpy-mirror',
    view_count: 245,
    created_at: '2026-06-04T10:30:00.000Z'
  },
  {
    id: 2,
    title: 'Japanese Fairy Tales 公版故事集',
    cover: '/covers/fairy-tales.svg',
    category: '轻小说',
    tags: '公版,民间故事,Project Gutenberg',
    description: 'Project Gutenberg 收录的日本民间故事合集，可作为轻小说栏目中的公版阅读素材和剧情参考资料。',
    download_url: 'https://www.gutenberg.org/ebooks/35853',
    view_count: 181,
    created_at: '2026-06-03T12:20:00.000Z'
  },
  {
    id: 3,
    title: 'VisualNovel/Anime/Manga CC0 素材合集',
    cover: '/covers/anime-assets.svg',
    category: '动漫资料',
    tags: 'CC0,角色立绘,背景素材',
    description: 'OpenGameArt 上的视觉小说、动漫、漫画方向 CC0 素材集合，包含角色、背景、头像和平台素材等。',
    download_url: 'https://opengameart.org/content/visualnovelanimemanga-cc0',
    view_count: 212,
    created_at: '2026-06-02T08:10:00.000Z'
  },
  {
    id: 4,
    title: 'RPG Character Sprites 角色行走图',
    cover: '/covers/rpg-sprites.svg',
    category: '动漫资料',
    tags: 'CC0,像素角色,RPG',
    description: 'OpenGameArt 的 CC0 像素角色素材，包含短发、长发、裙装和模板角色行走图，适合游戏原型或素材学习。',
    download_url: 'https://opengameart.org/content/rpg-character-sprites',
    view_count: 298,
    created_at: '2026-06-01T16:45:00.000Z'
  },
  {
    id: 5,
    title: 'EmptyCity 背景音乐',
    cover: '/covers/emptycity-music.svg',
    category: '音乐资源',
    tags: 'CC0,BGM,OGG',
    description: 'OpenGameArt 的 CC0 背景音乐资源，可用于游戏、视觉小说或演示项目中的城市氛围 BGM。',
    download_url: 'https://opengameart.org/content/emptycity-background-music',
    view_count: 156,
    created_at: '2026-05-31T11:00:00.000Z'
  },
  {
    id: 6,
    title: "Ren'Py Rhythm Game 开源模板",
    cover: '/covers/rhythm-template.svg',
    category: '工具资源',
    tags: "Ren'Py,开源,节奏游戏",
    description: "面向 Ren'Py 的节奏玩法模板，资源页提供源码和下载入口，适合展示工具资源与可扩展玩法。",
    download_url: 'https://r3dhummingbird.itch.io/renpy-rhythm-game',
    view_count: 124,
    created_at: '2026-05-30T14:15:00.000Z'
  },
  {
    id: 7,
    title: 'Project DVN 视觉小说引擎',
    cover: '/covers/dvn-engine.svg',
    category: '工具资源',
    tags: '视觉小说,开源,引擎',
    description: 'Project DVN 是免费开源的视觉小说引擎，强调无需复杂代码即可制作互动叙事作品。',
    download_url: 'https://projectdvn.com/',
    view_count: 87,
    created_at: '2026-05-29T09:35:00.000Z'
  },
  {
    id: 8,
    title: 'Characters CC0 角色素材包',
    cover: '/covers/characters-pack.svg',
    category: '动漫资料',
    tags: 'CC0,PNG,SVG,角色素材',
    description: 'OpenGameArt 的 CC0 角色素材包，包含 PNG 和 SVG 格式，适合动画资料、游戏素材和角色设定栏目。',
    download_url: 'https://opengameart.org/content/characters-11',
    view_count: 103,
    created_at: '2026-05-28T15:40:00.000Z'
  }
];

const sampleComments = [
  { id: 1, user_id: 2, resource_id: 1, content: '这个 SDK 链接很适合放在 Galgame 工具区，演示时也好说明。', created_at: '2026-06-05T09:12:00.000Z' },
  { id: 2, user_id: 1, resource_id: 1, content: '已确认是官方镜像页，下载入口清楚。', created_at: '2026-06-05T10:18:00.000Z' },
  { id: 3, user_id: 2, resource_id: 2, content: '公版故事集适合当轻小说分类的示例资源。', created_at: '2026-06-04T13:40:00.000Z' },
  { id: 4, user_id: 2, resource_id: 4, content: 'CC0 角色行走图对课程项目很实用。', created_at: '2026-06-03T15:33:00.000Z' },
  { id: 5, user_id: 1, resource_id: 5, content: '音乐资源建议在描述里保留授权说明。', created_at: '2026-06-02T19:50:00.000Z' }
];

const sampleRatings = [
  { id: 1, user_id: 2, resource_id: 1, score: 5, created_at: '2026-06-05T09:10:00.000Z' },
  { id: 2, user_id: 1, resource_id: 1, score: 4, created_at: '2026-06-05T10:12:00.000Z' },
  { id: 3, user_id: 2, resource_id: 2, score: 4, created_at: '2026-06-04T13:35:00.000Z' },
  { id: 4, user_id: 2, resource_id: 4, score: 5, created_at: '2026-06-03T15:30:00.000Z' },
  { id: 5, user_id: 1, resource_id: 5, score: 4, created_at: '2026-06-02T19:40:00.000Z' },
  { id: 6, user_id: 1, resource_id: 6, score: 3, created_at: '2026-06-01T08:30:00.000Z' }
];

module.exports = {
  sampleResources,
  sampleComments,
  sampleRatings
};
