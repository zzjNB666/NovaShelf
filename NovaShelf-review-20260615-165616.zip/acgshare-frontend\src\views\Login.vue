<script setup>
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { LogIn } from 'lucide-vue-next';
import { login } from '../api/auth';
import { setSession } from '../stores/auth';

const router = useRouter();
const route = useRoute();
const username = ref('admin');
const password = ref('admin123');
const error = ref('');
const loading = ref(false);

async function submit() {
  loading.value = true;
  error.value = '';
  try {
    const res = await login({
      username: username.value,
      password: password.value
    });
    setSession(res.data.data.token, res.data.data.user);
    router.push(String(route.query.redirect || '/'));
  } catch (err) {
    error.value = err.message;
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <section class="auth-layout">
    <form class="auth-form" @submit.prevent="submit">
      <h1>登录</h1>
      <label>
        <span>用户名</span>
        <input v-model.trim="username" autocomplete="username" required />
      </label>
      <label>
        <span>密码</span>
        <input v-model="password" type="password" autocomplete="current-password" required />
      </label>
      <p v-if="error" class="error-text">{{ error }}</p>
      <button class="button primary" type="submit" :disabled="loading">
        <LogIn :size="17" />
        <span>{{ loading ? '登录中' : '登录' }}</span>
      </button>
      <RouterLink class="text-link" to="/register">创建新账号</RouterLink>
    </form>
  </section>
</template>
