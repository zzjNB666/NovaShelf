<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue';
import { ChevronLeft, ChevronRight, RefreshCw, Search } from 'lucide-vue-next';
import ResourceCard from '../components/ResourceCard.vue';
import { categories } from '../constants';
import { getResources, normalizeResourceResponse } from '../api/resources';

const resources = ref([]);
const loading = ref(false);
const error = ref('');
const lastSyncedAt = ref('');
let refreshTimer = null;

const filters = reactive({
  keyword: '',
  category: '',
  sortBy: 'created_at',
  order: 'desc',
  page: 1,
  pageSize: 8
});

const pagination = reactive({
  page: 1,
  pageSize: 8,
  total: 0,
  totalPages: 1
});

const totalViews = computed(() => resources.value.reduce((sum, item) => sum + Number(item.view_count || 0), 0));
const avgScore = computed(() => {
  if (!resources.value.length) return '0.0';
  const total = resources.value.reduce((sum, item) => sum + Number(item.average_score || 0), 0);
  return (total / resources.value.length).toFixed(1);
});

async function loadResources({ silent = false } = {}) {
  if (!silent) {
    loading.value = true;
  }
  error.value = '';
  try {
    const res = await getResources({
      keyword: filters.keyword || undefined,
      category: filters.category || undefined,
      sortBy: filters.sortBy,
      order: filters.order,
      page: filters.page,
      pageSize: filters.pageSize
    });
    const payload = normalizeResourceResponse(res);
    resources.value = payload.items;
    Object.assign(pagination, payload.pagination);
    lastSyncedAt.value = new Date().toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  } catch (err) {
    error.value = err.message;
  } finally {
    if (!silent) {
      loading.value = false;
    }
  }
}

function resetAndLoad() {
  filters.page = 1;
  loadResources();
}

function selectCategory(category) {
  filters.category = filters.category === category ? '' : category;
  resetAndLoad();
}

function changePage(page) {
  if (page < 1 || page > pagination.totalPages || page === filters.page) return;
  filters.page = page;
  loadResources();
}

onMounted(() => {
  loadResources();
  refreshTimer = window.setInterval(() => {
    loadResources({ silent: true });
  }, 8000);
});

onBeforeUnmount(() => {
  window.clearInterval(refreshTimer);
});
</script>

<template>
  <section class="workspace-head">
    <div>
      <h1>ACG 资源库</h1>
      <p>游戏、轻小说、动漫资料、工具与音乐资源</p>
    </div>
    <form class="search-bar" @submit.prevent="resetAndLoad">
      <Search :size="19" />
      <input v-model.trim="filters.keyword" placeholder="搜索标题、标签或简介" />
      <button class="button primary" type="submit">
        <Search :size="17" />
        <span>搜索</span>
      </button>
    </form>
  </section>

  <section class="stats-strip" aria-label="资源统计">
    <div>
      <strong>{{ pagination.total }}</strong>
      <span>资源总数</span>
    </div>
    <div>
      <strong>{{ totalViews }}</strong>
      <span>本页访问</span>
    </div>
    <div>
      <strong>{{ avgScore }}</strong>
      <span>本页平均分</span>
    </div>
  </section>

  <div class="live-sync-row" aria-label="实时同步状态">
    <span class="signal-chip">Live Sync</span>
    <span>每 8 秒自动刷新当前页数据</span>
    <time v-if="lastSyncedAt">上次同步 {{ lastSyncedAt }}</time>
  </div>

  <section class="filter-row" aria-label="资源分类">
    <button
      class="segmented-item"
      :class="{ active: !filters.category }"
      type="button"
      @click="selectCategory('')"
    >
      全部
    </button>
    <button
      v-for="category in categories"
      :key="category"
      class="segmented-item"
      :class="{ active: filters.category === category }"
      type="button"
      @click="selectCategory(category)"
    >
      {{ category }}
    </button>
    <label class="inline-control">
      <span>排序</span>
      <select v-model="filters.sortBy" @change="resetAndLoad">
        <option value="created_at">发布时间</option>
        <option value="view_count">访问量</option>
        <option value="rating">评分</option>
        <option value="title">标题</option>
      </select>
    </label>
    <label class="inline-control">
      <span>方向</span>
      <select v-model="filters.order" @change="resetAndLoad">
        <option value="desc">降序</option>
        <option value="asc">升序</option>
      </select>
    </label>
    <button class="button ghost compact" type="button" @click="loadResources">
      <RefreshCw :size="16" />
      <span>刷新</span>
    </button>
  </section>

  <p v-if="error" class="error-text">{{ error }}</p>
  <p v-else-if="loading" class="empty-text">正在加载资源...</p>

  <template v-else>
    <section class="resource-grid" aria-label="资源列表">
      <ResourceCard v-for="item in resources" :key="item.id" :resource="item" />
      <p v-if="!resources.length" class="empty-text">没有找到匹配资源</p>
    </section>

    <nav v-if="pagination.totalPages > 1" class="pagination-bar" aria-label="分页">
      <button class="button ghost compact" type="button" :disabled="pagination.page <= 1" @click="changePage(pagination.page - 1)">
        <ChevronLeft :size="16" />
        <span>上一页</span>
      </button>
      <span>第 {{ pagination.page }} / {{ pagination.totalPages }} 页，共 {{ pagination.total }} 条</span>
      <button class="button ghost compact" type="button" :disabled="pagination.page >= pagination.totalPages" @click="changePage(pagination.page + 1)">
        <span>下一页</span>
        <ChevronRight :size="16" />
      </button>
    </nav>
  </template>
</template>
