export const categoryOptions = [
  { value: 'Galgame', label: '互动剧本' },
  { value: '轻小说', label: '叙事文本' },
  { value: '动漫资料', label: '视觉设定' },
  { value: '工具资源', label: '创作工具' },
  { value: '音乐资源', label: '声音素材' },
  { value: '其他', label: '灵感备忘' }
];

export const categories = categoryOptions.map((item) => item.value);

export function getCategoryLabel(value) {
  return categoryOptions.find((item) => item.value === value)?.label || value || '灵感备忘';
}
